// ============================================================
// Manhwa Tracker — Background Service Worker
// Handles storage, deduplication, and SPA detection
// ============================================================

const STORAGE_KEY = "manhwa_tracker_list";
const SETTINGS_KEY = "manhwa_tracker_settings";

// ── Helpers ──────────────────────────────────────────────────

async function getList() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  return result[STORAGE_KEY] || [];
}

async function saveList(list) {
  await chrome.storage.local.set({ [STORAGE_KEY]: list });
}

async function getSettings() {
  const result = await chrome.storage.local.get(SETTINGS_KEY);
  return result[SETTINGS_KEY] || {};
}

const ANALYTICS_KEY = "manhwa_log_analytics";

function canonicalTitle(title) {
  if (!title) return "";
  // Normalize to lowercase words only — preserves boundaries to avoid false merges
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// ── Fuzzy Title Matching ──────────────────────────────────────

/**
 * Standard dynamic-programming Levenshtein distance.
 * Operates on already-canonicalized strings for efficiency.
 */
function levenshteinDistance(a, b) {
  const m = a.length;
  const n = b.length;
  // dp[i][j] = edit distance between a[0..i-1] and b[0..j-1]
  const dp = Array.from({ length: m + 1 }, (_, i) => {
    const row = new Array(n + 1).fill(0);
    row[0] = i;
    return row;
  });
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (a[i - 1] === b[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
  }
  return dp[m][n];
}

/**
 * Fast-path: exact canonical match.
 * Slow-path: Levenshtein ≤ 3 on canonical strings.
 * Threshold 3 is intentional — keeps "Tower of God" / "Tower of Greed" (distance 4) separate.
 * Returns the matched list item, or null.
 */
function fuzzyTitleMatch(newTitle, list) {
  const target = canonicalTitle(newTitle);

  // 1. Exact canonical match (O(n), no Levenshtein cost)
  const exact = list.find(item => canonicalTitle(item.title) === target);
  if (exact) return exact;

  // 2. Fuzzy match — find closest entry within threshold
  const THRESHOLD = 3;
  let bestMatch = null;
  let bestDist = Infinity;

  for (const item of list) {
    const dist = levenshteinDistance(target, canonicalTitle(item.title));
    if (dist <= THRESHOLD && dist < bestDist) {
      bestDist = dist;
      bestMatch = item;
    }
  }

  return bestMatch;
}

async function getAnalytics() {
  const res = await chrome.storage.local.get(ANALYTICS_KEY);
  return res[ANALYTICS_KEY] || { totalChapters: 0, daily: {}, titles: {} };
}

async function trackAnalytics(data) {
  const analytics = await getAnalytics();
  const today = new Date().toISOString().slice(0, 10);

  analytics.totalChapters += 1;
  analytics.daily[today] = (analytics.daily[today] || 0) + 1;

  const titleKey = canonicalTitle(data.title);
  analytics.titles[titleKey] = (analytics.titles[titleKey] || 0) + 1;

  // Prune daily keys older than 90 days to prevent unbounded growth
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 90);
  const cutoffStr = cutoff.toISOString().slice(0, 10);
  for (const key of Object.keys(analytics.daily)) {
    if (key < cutoffStr) delete analytics.daily[key];
  }

  await chrome.storage.local.set({ [ANALYTICS_KEY]: analytics });
}

// ── Main update logic ─────────────────────────────────────────

async function updateProgress(data) {
  let list = await getList();
  let cleanTitle = data.title;

  // Guard: reject invalid chapter numbers to prevent data corruption
  if (!cleanTitle || cleanTitle.toLowerCase() === "read") return;
  if (!data.chapter || isNaN(data.chapter) || data.chapter <= 0) return;

  const matched = fuzzyTitleMatch(cleanTitle, list);
  const idx = matched ? list.indexOf(matched) : -1;

  const updatedEntry = {
    id: idx >= 0 ? list[idx].id : Date.now().toString(),
    title: idx >= 0 ? list[idx].title : cleanTitle, // Keep first seen title variant
    lastChapter: data.chapter,
    lastURL: data.url,
    nextURL: data.nextURL || null,
    site: data.site,
    updatedAt: data.timestamp,
    addedAt: idx >= 0 ? list[idx].addedAt : data.timestamp,
    sources: idx >= 0 ? (list[idx].sources || []) : [],
    history: idx >= 0 ? (list[idx].history || []) : []
  };

  // Merge sources — capped at 5 most recent to prevent unbounded growth
  const sourceExists = updatedEntry.sources.some(s => s.site === data.site);
  if (!sourceExists) {
    updatedEntry.sources = [
      { site: data.site, url: data.url },
      ...updatedEntry.sources
    ].slice(0, 5);
  }

  let prevChapter = null;

  if (idx >= 0) {
    const existing = list[idx];
    prevChapter = existing.lastChapter;
    if (data.chapter < existing.lastChapter) return;
    if (data.chapter === existing.lastChapter && data.url === existing.lastURL) return;

    // Track history
    if (existing.lastChapter !== data.chapter) {
      updatedEntry.history = [
        { chapter: existing.lastChapter, url: existing.lastURL, ts: existing.updatedAt },
        ...existing.history
      ].slice(0, 20);
    }
    list[idx] = updatedEntry;
  } else {
    list.unshift(updatedEntry);
  }

  // Change 4: retry-on-fail save
  let saved = false;
  try {
    await saveList(list);
    saved = true;
  } catch {
    await new Promise(r => setTimeout(r, 500));
    try {
      await saveList(list);
      saved = true;
    } catch {
      chrome.action.setBadgeText({ text: "\u2717" });
      chrome.action.setBadgeBackgroundColor({ color: "#c84b2f" });
      return;
    }
  }

  // Only count analytics when the chapter has actually advanced (not revisits)
  const isNewChapter = prevChapter === null || data.chapter !== prevChapter;
  if (isNewChapter) await trackAnalytics(data);

  chrome.action.setBadgeText({ text: "✓" });
  chrome.action.setBadgeBackgroundColor({ color: "#e06040" });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 2000);

  // Change 3: warn if storage approaches 10MB cap
  await checkStorageQuota();

  return updatedEntry;
}

// ── Storage Quota Guard (Change 3) ───────────────────────────

async function checkStorageQuota() {
  const bytesInUse = await chrome.storage.local.getBytesInUse(null);
  if (bytesInUse > 8_000_000) {
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#e0a040" });
  }
}

// ── SPA / URL Change Tracking ────────────────────────────────
// Background detects URL changes (including pushState) and notifies content script
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    chrome.tabs.sendMessage(tabId, { type: "URL_CHANGED", url: changeInfo.url }).catch(() => {});
  }
});

// ── Message handler ───────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_MANTA_DATA") {
    if (!sender.tab || !sender.tab.id) {
      sendResponse(null);
      return true;
    }
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      func: () => window.MantaDataLayer,
      world: "MAIN"
    }).then(res => {
      sendResponse(res[0]?.result || null);
    }).catch(() => {
      sendResponse(null);
    });
    return true; // keep channel open
  }

  if (message.type === "CHAPTER_DETECTED") {
    updateProgress(message.data).then(entry => {
      sendResponse({ success: true, entry });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }

  if (message.type === "GET_LIST") {
    getList().then(list => sendResponse({ list }));
    return true;
  }

  if (message.type === "DELETE_ENTRY") {
    getList().then(async list => {
      const filtered = list.filter(item => item.id !== message.id);
      await saveList(filtered);
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === "GET_SETTINGS") {
    getSettings().then(settings => sendResponse({ settings }));
    return true;
  }

  if (message.type === "SAVE_SETTINGS") {
    chrome.storage.local.set({ [SETTINGS_KEY]: message.settings }).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === "MANUAL_ADD") {
    updateProgress(message.data).then(entry => {
      sendResponse({ success: true, entry });
    });
    return true;
  }

  if (message.type === "EXPORT_LIST") {
    getList().then(list => {
      sendResponse({ list });
    });
    return true;
  }

  if (message.type === "IMPORT_LIST") {
    getList().then(async existingList => {
      const newList = message.list;
      const merged = [...existingList];

      newList.forEach(newItem => {
        const existingMatch = fuzzyTitleMatch(newItem.title, merged);
        const idx = existingMatch ? merged.indexOf(existingMatch) : -1;

        if (idx >= 0) {
          // Keep the one with the higher chapter
          if (newItem.lastChapter > merged[idx].lastChapter) {
            merged[idx] = { ...newItem };
          }
        } else {
          merged.unshift(newItem);
        }
      });

      // Sort by updatedAt
      merged.sort((a, b) => b.updatedAt - a.updatedAt);
      await saveList(merged);
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === "GET_ANALYTICS") {
    getAnalytics().then(analytics => sendResponse({ analytics }));
    return true;
  }
});
